using UnityEngine;

namespace ONYX {
    public class ReadOnlyAttribute : PropertyAttribute { }
}